
  # Hero Details Viewer

  This is a code bundle for Hero Details Viewer. The original project is available at https://www.figma.com/design/E3L9SDIb2y9YawcBH1NcIr/Hero-Details-Viewer.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  