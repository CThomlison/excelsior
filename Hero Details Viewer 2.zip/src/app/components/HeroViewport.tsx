import { motion } from "motion/react";
import { Hero } from "../../data/heroes";

interface HeroViewportProps {
  hero: Hero;
}

export function HeroViewport({ hero }: HeroViewportProps) {
  return (
    <div className="relative w-full h-full flex flex-col items-center justify-center pointer-events-none z-10 perspective-[1000px]">
      
      {/* Platform/Pedestal */}
      <motion.div
        initial={{ y: 100, scale: 0.8, opacity: 0 }}
        animate={{ y: 0, scale: 1, opacity: 1 }}
        transition={{ type: "spring", stiffness: 100 }}
        className="absolute bottom-20 w-[400px] h-[400px] md:w-[600px] md:h-[600px] rounded-full bg-gradient-to-t from-cyan-500/20 via-purple-500/10 to-transparent blur-3xl"
      />

      <div className="relative w-full h-full flex items-center justify-center">
        {/* Background Layer: 2D Cutout (Semi-transparent) */}
        <motion.div
          key={hero.id + "-bg-art"}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 0.25, scale: 1.2 }}
          exit={{ opacity: 0, scale: 1.3 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className="absolute inset-0 flex items-center justify-center z-0"
        >
          <img 
            src={hero.fullArtUrl} 
            alt={`${hero.name} Art`} 
            className="h-[85vh] w-auto object-contain mix-blend-overlay filter blur-[2px] opacity-60"
          />
        </motion.div>

        {/* Foreground Layer: Roblox Model */}
        <motion.div
          key={hero.id + "-model"}
          initial={{ y: -50, opacity: 0, rotateY: -180 }}
          animate={{ y: 0, opacity: 1, rotateY: 0 }}
          exit={{ y: 50, opacity: 0, rotateY: 180 }}
          transition={{ type: "spring", stiffness: 80, damping: 15 }}
          className="relative z-20 flex items-center justify-center drop-shadow-[0_20px_50px_rgba(0,0,0,0.5)]"
        >
          <img 
            src={hero.robloxUrl} 
            alt={`${hero.name} 3D Model`} 
            className="h-[60vh] md:h-[70vh] w-auto object-contain hover:scale-105 transition-transform duration-500 ease-out cursor-grab active:cursor-grabbing pointer-events-auto"
            style={{ filter: "drop-shadow(0 0 20px rgba(255, 255, 255, 0.1))" }}
          />
          
          {/* Subtle ground reflection for the model */}
          <div className="absolute -bottom-8 w-[60%] h-8 bg-black/40 rounded-[100%] blur-xl" />
        </motion.div>
      </div>
    </div>
  );
}
