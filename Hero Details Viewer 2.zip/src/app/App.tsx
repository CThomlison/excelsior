import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { HEROES, Hero } from "./data/heroes";
import { HeroSidebar } from "./components/HeroSidebar";
import { HeroViewport } from "./components/HeroViewport";
import { HeroHeader } from "./components/HeroHeader";
import { SkillBar } from "./components/SkillBar";
import { InfoCard } from "./components/InfoCard";

export default function App() {
  const [selectedHero, setSelectedHero] = useState<Hero>(HEROES[0]);
  const [showInfo, setShowInfo] = useState(false);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-900 font-['Rubik'] text-white select-none">
      
      {/* 3D-ish Background World */}
      <div className="absolute inset-0 z-0">
        {/* Sky Gradient */}
        <div className="absolute inset-0 bg-gradient-to-b from-sky-400 via-sky-200 to-white" />
        
        {/* Dynamic Theme Layer */}
        <AnimatePresence mode="wait">
           <motion.div 
             key={selectedHero.id}
             initial={{ opacity: 0 }}
             animate={{ opacity: 1 }}
             exit={{ opacity: 0 }}
             transition={{ duration: 1 }}
             className="absolute inset-0 bg-gradient-to-tr from-purple-500/20 via-transparent to-orange-500/20 mix-blend-overlay"
           />
        </AnimatePresence>

        {/* Grid Floor */}
        <div className="absolute bottom-0 w-full h-[50vh] bg-[linear-gradient(to_bottom,transparent,rgba(0,0,0,0.1)_1px),linear-gradient(to_right,rgba(0,0,0,0.1)_1px,transparent_1px)] bg-[size:40px_40px] [transform:perspective(1000px)_rotateX(60deg)_scale(2)] origin-bottom opacity-40 pointer-events-none" />
        
        {/* Clouds / Floating Shapes */}
        <div className="absolute top-20 left-20 w-32 h-32 bg-white/40 rounded-full blur-3xl animate-pulse" />
        <div className="absolute top-40 right-40 w-64 h-64 bg-yellow-200/30 rounded-full blur-3xl animate-pulse delay-700" />
      </div>

      {/* Main UI Layer */}
      <div className="relative z-10 w-full h-full flex flex-col md:flex-row p-4 md:p-6 gap-4 pointer-events-none">
        
        {/* Left Column: Header & Info Button */}
        <div className="flex flex-col items-start gap-4 pointer-events-auto z-20 md:w-1/3">
          <HeroHeader hero={selectedHero} />
          
          <motion.button
             whileHover={{ scale: 1.05 }}
             whileTap={{ scale: 0.95 }}
             onClick={() => setShowInfo(!showInfo)}
             className="hidden md:flex items-center gap-2 bg-white/90 backdrop-blur-md text-slate-800 px-6 py-3 rounded-2xl shadow-[0_4px_0_rgba(0,0,0,0.1)] font-black text-lg hover:bg-white transition-colors"
          >
             {showInfo ? "HIDE INFO" : "VIEW INFO"}
             <div className="w-6 h-6 bg-slate-200 rounded-full flex items-center justify-center text-xs">i</div>
          </motion.button>

          <AnimatePresence>
            {showInfo && (
               <InfoCard hero={selectedHero} onClose={() => setShowInfo(false)} />
            )}
          </AnimatePresence>
        </div>

        {/* Center: Hero Viewport */}
        <div className="absolute inset-0 md:inset-x-20 z-0 flex items-center justify-center pointer-events-none">
           <HeroViewport hero={selectedHero} />
        </div>

        {/* Right Column: Hero List (Sidebar) */}
        <div className="absolute right-4 top-4 bottom-24 md:bottom-4 w-20 md:w-24 flex flex-col items-center pointer-events-auto z-20">
           <HeroSidebar 
             heroes={HEROES} 
             selectedHeroId={selectedHero.id} 
             onSelect={setSelectedHero} 
           />
        </div>
        
        {/* Bottom Center: Skills Dock */}
        <div className="absolute bottom-4 left-4 right-4 md:left-1/2 md:-translate-x-1/2 md:w-auto pointer-events-auto z-30 flex justify-center">
           <SkillBar hero={selectedHero} />
        </div>
      </div>
    </div>
  );
}
